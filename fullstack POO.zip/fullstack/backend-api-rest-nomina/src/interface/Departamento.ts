export interface Idepartamento {
  id?: number;
  descripcion: string;
  estado: number;
  created_at: Date;
}
