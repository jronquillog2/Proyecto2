export interface Icargo {
  id?: number;
  descripcion: string;
  estado: number;
  created_at: Date;
}
